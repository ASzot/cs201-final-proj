var stompClient = null;
var socket ;

/**
 * 	<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/1.7.2/socket.io.js"></script>
    	<script src="CryptoCompareUtility.js"></script>
 *  INCLUDE THESE files^^
 *  Make sure to include pom dependencies
 */

//Prepares table by listening to many exchanges for trades
//One exchange alone produces slow enough trades that it may not be fast enough for demo
function addSubscriptionCurrency() {
	var subscriptionList = [];
	var exchangesList = ["Cryptsy", "Bitstamp", "OKCoin", "Coinbase", "Poloniex", "Cexio", "BTCE", "BitTrex", "Kraken", "Bitfinex", "LocalBitcoins", 
						"itBit", "HitBTC", "Coinfloor", "Huobi", "LakeBTC", "Coinsetter", "CCEX", "MonetaGo", "Gatecoin", "Gemini", "CCEDK", "Exmo", 
						"Yobit", "BitBay", "QuadrigaCX", "BitSquare", "TheRockTrading", "Quoine", "LiveCoin", "WavesDEX", "Lykke", "Remitano", 
						"Coinroom", "Abucoins"];
	var subscriptionID = 0; // 0 as subscriptionID means trade data
	var toCurrency = "USD";
	var fromCurrency = $("#fromCurrency").val(); //determined by current currency on page

	for (var i = 0; i < exchangesList.length; i++) {
		var subscription = subscriptionID + "~" + exchangesList[i] + "~" + fromCurrency + "~" + toCurrency;
		subscriptionList.push(subscription);
	}
	
	console.log(subscriptionList);
	socket.emit('SubAdd', { subs: subscriptionList });
}

//displays the received trade
function addToCoinUpdates(parsedMessage) {
//	console.log(parsedMessage);
//	var fromCur = CCC.STATIC.CURRENCY.getSymbol("BTC");
	var toCur = CCC.STATIC.CURRENCY.getSymbol("USD");
	
	var from = parsedMessage['F'];
	var transactionType = "";
	if (from == 1) transactionType = "BUY";
	else if (from == 2) transactionType = "SELL";
	else transactionType == "UNKNOWN";
	
	var exchange = parsedMessage['M'];
	var price = parsedMessage['P'];
	var quantity = parsedMessage['Q'];
	var total = parsedMessage['TOTAL'];
	
	var priceString = CCC.convertValueToDisplay(toCur, price);
	var quantityString = CCC.convertValueToDisplay("", quantity);
	var totalString = CCC.convertValueToDisplay(toCur, total);
	
	var message = {
		transactionType: transactionType,
		exchange: exchange,
		price: priceString,
		quantity: quantityString,
		total: totalString
	};
	
	message = "Transaction type: " + message.transactionType + " Exchange: " + message.exchange + " Price: " + message.price + " Quantity: " + message.quantity + " Total: " + message.total;
	$("#coinUpdates").append(message + '<br>');
}

$(function () {
    $("form").on('submit', function (e) {
        e.preventDefault();
    });
    $( "#sendTrade" ).click(function() { addSubscriptionCurrency(); });

	socket = io.connect('https://streamer.cryptocompare.com/');

	socket.on("m", function(message) {
		parsedMessage = CCC.TRADE.unpack(message);
		addToCoinUpdates(parsedMessage);
	});
    
    
});

