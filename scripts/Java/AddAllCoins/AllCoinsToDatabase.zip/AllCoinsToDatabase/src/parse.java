import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class parse {
	
	static Vector<String> tickers = new Vector<String>();
	
	public static void main (String [] args) {
		File file = new File("AllCoins.txt");
		String line;
		
		
		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
			
			while (true) {
				if ((line=br.readLine()) != null) {
					
					try {
						String[] splited = line.split("\\s+");
						//System.out.println(splited[0]);
						tickers.add(splited[0]);
					} catch (ArrayIndexOutOfBoundsException aioobe) {
						addToDatabase();
						return;
					}
					
				}
			}
			
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException e) {
	        e.printStackTrace();
		}
	}
	
	
	parse(){
		
	}
	
	public static void addToDatabase(){
		Connection conn = null;
		Statement st = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		
		PreparedStatement preparedStatement = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://107.180.58.50/csci201l_FinalProject?user=fp_admin&password=admin&useSSL=false");
			
			String toInsert = "INSERT INTO CurrencyInfo"
								+ "(ticker) VALUES"
								+ "(?)";
			
			
			preparedStatement = conn.prepareStatement(toInsert);
				
			conn.setAutoCommit(false);
				
			for(int i=0; i<tickers.size(); i++) {
				System.out.println("Adding: "+ tickers.get(i));
				preparedStatement.setString(1, tickers.get(i));
				preparedStatement.addBatch();
			}
			preparedStatement.executeBatch();
			conn.commit();
			System.out.println("Added All Tickers");
			return;
			
		} catch (SQLException sqle) {
			System.out.println ("SQLException: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println ("ClassNotFoundException: " + cnfe.getMessage());
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
	}
}
