package GetData;

public class superhero {

}
