package GetData;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import JDBCDriver.ConnectToDB;

public class User {
	
	public User(){
		
	}
	
	static boolean validateUser(String Username, String Password) {
		Connection conn = ConnectToDB.getDBConnection();
		boolean IsValidUser = false;
		
		try {
			String validationStatement = "SELECT * FROM User where username=?";
			
			PreparedStatement ps = conn.prepareStatement(validationStatement);
			ps.setString(1, Username);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				String un = rs.getString("username");
				String pass = rs.getString("hashed_password");
				if(Username.equals(Username) && Password.equals(pass)) {
					IsValidUser = true;
					return IsValidUser;
				}
			}
			
		} catch(Exception e){
			return IsValidUser;
		}
		return IsValidUser;
	}
}
