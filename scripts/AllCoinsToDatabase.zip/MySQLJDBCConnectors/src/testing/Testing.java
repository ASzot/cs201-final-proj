package testing;

import GetData.*;

public class Testing {
	
	
	User myUser = new User();
	
	myUser.validateUser("testUser1", "testing");
}
